makeself . ../aliview.install.run "Installer for AliView" ./install.sh 
